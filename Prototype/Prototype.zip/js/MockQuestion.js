﻿{
    questionId:1,
    question: "What colour is the sky",

    answers: [
        {id:1,text:"It's blue"},
        {id:2,text:"It's green"},
        {id:3,text:"It's yellow"}
    ]


}